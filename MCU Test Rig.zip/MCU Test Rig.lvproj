﻿<?xml version='1.0' encoding='UTF-8'?>
<Project Type="Project" LVVersion="25008000">
	<Property Name="NI.LV.All.SaveVersion" Type="Str">25.0</Property>
	<Property Name="NI.LV.All.SourceOnly" Type="Bool">true</Property>
	<Property Name="NI.Project.Description" Type="Str"></Property>
	<Item Name="My Computer" Type="My Computer">
		<Property Name="NI.SortType" Type="Int">3</Property>
		<Property Name="server.app.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="server.control.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="server.tcp.enabled" Type="Bool">false</Property>
		<Property Name="server.tcp.port" Type="Int">0</Property>
		<Property Name="server.tcp.serviceName" Type="Str">My Computer/VI Server</Property>
		<Property Name="server.tcp.serviceName.default" Type="Str">My Computer/VI Server</Property>
		<Property Name="server.vi.callsEnabled" Type="Bool">true</Property>
		<Property Name="server.vi.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="specify.custom.address" Type="Bool">false</Property>
		<Item Name="Project Documentation" Type="Folder"/>
		<Item Name="Error Handlers" Type="Folder"/>
		<Item Name="Globals" Type="Folder"/>
		<Item Name="Support VIs" Type="Folder">
			<Property Name="NI.SortType" Type="Int">3</Property>
		</Item>
		<Item Name="Type Definitions" Type="Folder">
			<Property Name="NI.SortType" Type="Int">0</Property>
		</Item>
		<Item Name="Main Daq routine.vi" Type="VI" URL="../../../Main Daq routine.vi"/>
		<Item Name="Read Configuration (INI) File.vi" Type="VI" URL="/D/MCU Test RIG/Read Configuration (INI) File.vi"/>
		<Item Name="Datalogger.vi" Type="VI" URL="../../../../Downloads/Datalogger.vi"/>
		<Item Name="Dependencies" Type="Dependencies"/>
		<Item Name="Build Specifications" Type="Build">
			<Item Name="Generic Real-Time Waveform Acquisition and Logging UI" Type="EXE">
				<Property Name="App_copyErrors" Type="Bool">true</Property>
				<Property Name="App_INI_aliasGUID" Type="Str">{C554F6E6-4FFF-4E5D-ABE6-305E9DDA0A26}</Property>
				<Property Name="App_INI_GUID" Type="Str">{62464553-0192-49ED-AE9B-16658031A9C9}</Property>
				<Property Name="App_serverConfig.httpPort" Type="Int">8002</Property>
				<Property Name="App_serverType" Type="Int">1</Property>
				<Property Name="Bld_buildCacheID" Type="Str">{4F04A458-D5C2-4E35-B26E-367FDC9017D9}</Property>
				<Property Name="Bld_buildSpecName" Type="Str">Generic Real-Time Waveform Acquisition and Logging UI</Property>
				<Property Name="Bld_excludeLibraryItems" Type="Bool">true</Property>
				<Property Name="Bld_excludePolymorphicVIs" Type="Bool">true</Property>
				<Property Name="Bld_localDestDir" Type="Path">../builds/NI_AB_PROJECTNAME/Generic Real-Time Waveform Acquisition and Logging UI</Property>
				<Property Name="Bld_localDestDirType" Type="Str">relativeToCommon</Property>
				<Property Name="Bld_modifyLibraryFile" Type="Bool">true</Property>
				<Property Name="Bld_previewCacheID" Type="Str">{DAAD6869-BBB9-4FC1-8BFC-D6C3006A19BA}</Property>
				<Property Name="Bld_version.major" Type="Int">1</Property>
				<Property Name="Destination[0].destName" Type="Str">GenericRealTimeWaveformAcquisitionandLogging UI.exe</Property>
				<Property Name="Destination[0].path" Type="Path">../builds/NI_AB_PROJECTNAME/Generic Real-Time Waveform Acquisition and Logging UI/GenericRealTimeWaveformAcquisitionandLogging UI.exe</Property>
				<Property Name="Destination[0].preserveHierarchy" Type="Bool">true</Property>
				<Property Name="Destination[0].type" Type="Str">App</Property>
				<Property Name="Destination[1].destName" Type="Str">Support Directory</Property>
				<Property Name="Destination[1].path" Type="Path">../builds/NI_AB_PROJECTNAME/Generic Real-Time Waveform Acquisition and Logging UI/data</Property>
				<Property Name="DestinationCount" Type="Int">2</Property>
				<Property Name="Source[0].itemID" Type="Str">{DAFA3238-037F-4E96-BFFC-C2E22AAACD6E}</Property>
				<Property Name="Source[0].type" Type="Str">Container</Property>
				<Property Name="Source[1].destinationIndex" Type="Int">0</Property>
				<Property Name="Source[1].itemID" Type="Ref"></Property>
				<Property Name="Source[1].sourceInclusion" Type="Str">TopLevel</Property>
				<Property Name="Source[1].type" Type="Str">VI</Property>
				<Property Name="SourceCount" Type="Int">2</Property>
				<Property Name="TgtF_fileDescription" Type="Str">Generic Real-Time Waveform Acquisition and Logging UI</Property>
				<Property Name="TgtF_internalName" Type="Str">Generic Real-Time Waveform Acquisition and Logging UI</Property>
				<Property Name="TgtF_legalCopyright" Type="Str">Copyright © 2012 </Property>
				<Property Name="TgtF_productName" Type="Str">Generic Real-Time Waveform Acquisition and Logging UI</Property>
				<Property Name="TgtF_targetfileGUID" Type="Str">{6CFF9783-C161-496B-969E-D5C2E2E632BC}</Property>
				<Property Name="TgtF_targetfileName" Type="Str">GenericRealTimeWaveformAcquisitionandLogging UI.exe</Property>
			</Item>
		</Item>
	</Item>
</Project>
